#!/usr/bin/env python3
"""Collect small, existing benchmark evidence after the paired run finishes.

Run this on EC2, then download the archive and its .sha256 sidecar. It invokes
no external tools and never executes or modifies benchmark inputs/results.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile
import tempfile


RUNS = ("out/benchmark/official/sampler-001", "out/benchmark/official/unit-suite-001")
AUXILIARY = ("out/benchmark/reference", "out/benchmark/preparation",
             "out/benchmark/setup", "out/benchmark/replays-single-001",
             "target/test-reports")
SUFFIXES = {".json", ".log", ".resources", ".csv", ".exit", ".xml", ".time", ".md"}
TEXT_NAMES = {"versions.txt", "SHA256SUMS"}
PRUNE = {"obj_dir", "verilated-sources", "generated-sources", "primary-sources",
         "support-artifacts", "workdir-verilator", ".git", ".venv", "__pycache__"}
ARCHIVE_ROOT = "benchmark-evidence"


def now():
    return datetime.now(timezone.utc).isoformat()


def eligible(path):
    return path.suffix.lower() in SUFFIXES or path.name in TEXT_NAMES


def permitted(repo, path):
    """Reject paths escaping the two evidence scopes, including through symlinks."""
    try:
        relative = path.resolve().relative_to(repo)
    except ValueError:
        return False
    return relative.parts[:2] in (("out", "benchmark"), ("target", "test-reports"))


def read_json(path):
    return json.loads(path.read_text())


def readiness(repo, expected_pairs):
    completion = repo / RUNS[1] / "completed.exit"
    if not completion.is_file() or completion.is_symlink():
        raise ValueError(f"Bulk run has not finished: missing {completion}")
    exit_text = completion.read_text().strip()
    if not re.fullmatch(r"-?\d+", exit_text):
        raise ValueError("completed.exit does not contain a numeric exit status")
    pairs = {}
    for run in RUNS:
        directory = repo / run
        for name in ("provenance.json", "summary.json", "results.json"):
            if not (directory / name).is_file():
                raise ValueError(f"Required final evidence is missing: {directory / name}")
        records = read_json(directory / "results.json")
        if not isinstance(records, list) or not records:
            raise ValueError(f"No result records in {directory}")
        for record in records:
            if record.get("engine") not in ("arcilator", "verilator"):
                raise ValueError(f"Unexpected engine in {directory}")
            frontend = record.get("frontend", {})
            if "exit_code" not in frontend or "runs" not in record:
                raise ValueError(f"Incomplete stage metadata in {directory}")
            if frontend["exit_code"] == 0 and not frontend.get("timed_out") and not record["runs"]:
                raise ValueError(f"Runtime result missing after successful frontend in {directory}")
            pairs.setdefault(record["bench"], set()).add(record["engine"])
    unpaired = sorted(name for name, engines in pairs.items()
                      if engines != {"arcilator", "verilator"})
    if unpaired or len(pairs) != expected_pairs:
        raise ValueError(f"Expected {expected_pairs} completed paired cases; found {len(pairs)} names, unpaired={unpaired}")
    return {"bulk_exit_code": int(exit_text), "paired_case_count": len(pairs),
            "case_names": sorted(pairs),
            "note": "Completion is independent of PASS; a completed run may contain failures/timeouts."}


def enumerate_evidence(repo):
    candidates = set()
    omitted = []

    def add(path):
        if not permitted(repo, path):
            omitted.append({"path": str(path), "reason": "outside evidence scopes"})
        elif path.is_symlink():
            omitted.append({"path": str(path.relative_to(repo)), "reason": "symlink"})
        elif path.is_file() and eligible(path):
            candidates.add(path.resolve())

    def walk(root):
        if not root.exists():
            omitted.append({"path": str(root.relative_to(repo)), "reason": "optional evidence root absent"})
            return
        if not permitted(repo, root) or root.is_symlink():
            omitted.append({"path": str(root), "reason": "unapproved or symlink root"})
            return
        for directory, children, names in os.walk(root, followlinks=False):
            current = Path(directory)
            children[:] = sorted(child for child in children
                                 if child not in PRUNE and not (current / child).is_symlink())
            for name in names:
                add(current / name)

    for relative in (*RUNS, *AUXILIARY):
        walk(repo / relative)
    # Shell-launch logs and completion/provenance files can live next to runs.
    official = repo / "out/benchmark/official"
    for path in official.iterdir():
        if path.is_file():
            add(path)
    # Preserve the precise manifests named by run provenance, even if a future
    # run used a different replay directory. Never follow RTL or trace paths.
    for run in RUNS:
        provenance = read_json(repo / run / "provenance.json")
        value = provenance.get("manifest")
        if not isinstance(value, str):
            continue
        manifest = Path(value)
        if not manifest.is_absolute():
            manifest = repo / manifest
        add(manifest)
        if not manifest.exists():
            omitted.append({"path": str(manifest), "reason": "referenced manifest absent"})
        if permitted(repo, manifest) and manifest.is_file() and not manifest.is_symlink():
            for sibling in ("conversion-report.json", "conversion.log"):
                add(manifest.with_name(sibling))
            for bench in read_json(manifest).get("benches", []):
                cwd = bench.get("cwd")
                if isinstance(cwd, str) and Path(cwd).is_absolute():
                    add(Path(cwd) / "replay.json")
    return sorted(candidates), omitted


def tar_bytes(archive, relative, data, mtime):
    info = tarfile.TarInfo(f"{ARCHIVE_ROOT}/{relative}")
    info.size = len(data)
    info.mode = 0o644
    info.mtime = mtime
    archive.addfile(info, io.BytesIO(data))


def collect(repo, output, max_file_bytes, max_total_bytes, expected_pairs):
    repo, output = repo.resolve(), output.resolve()
    state = readiness(repo, expected_pairs)
    candidates, omitted = enumerate_evidence(repo)
    output.parent.mkdir(parents=True, exist_ok=True)
    checksum_path = Path(str(output) + ".sha256")
    inventory_path = Path(str(output) + ".inventory.json")
    if any(path.exists() for path in (output, checksum_path, inventory_path)):
        raise ValueError("Choose a fresh output filename; existing audit artifacts are preserved")
    inventory = {"schema_version": 1, "created_utc": now(), "repository": str(repo),
                 "readiness": state, "official_runs": list(RUNS),
                 "included": [], "omitted": omitted,
                 "excluded_by_policy": {"directory_names": sorted(PRUNE),
                                        "eligible_suffixes": sorted(SUFFIXES),
                                        "note": "MLIR, RTL/native generated code, binaries, objects, waveform files, replay.txt and execution-script.txt are excluded."},
                 "max_file_bytes": max_file_bytes, "max_total_bytes": max_total_bytes}
    total = 0
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=output.name + ".", suffix=".partial", delete=False) as tmp:
            temp_name = Path(tmp.name)
        with tarfile.open(temp_name, "w:gz", compresslevel=6) as archive:
            for path in candidates:
                before = path.lstat()
                relative = str(path.relative_to(repo))
                if not stat.S_ISREG(before.st_mode):
                    inventory["omitted"].append({"path": relative, "reason": "not a regular file"})
                    continue
                if before.st_size > max_file_bytes or total + before.st_size > max_total_bytes:
                    inventory["omitted"].append({"path": relative, "bytes": before.st_size,
                                                 "reason": "file or total size limit"})
                    continue
                data = path.read_bytes()
                after = path.lstat()
                if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
                    raise ValueError(f"Evidence changed during collection: {path}; retry after activity ends")
                sha256 = hashlib.sha256(data).hexdigest()
                inventory["included"].append({"path": relative, "bytes": len(data),
                                               "sha256": sha256, "mtime_ns": before.st_mtime_ns})
                total += len(data)
                tar_bytes(archive, relative, data, int(before.st_mtime))
            inventory["included_file_count"] = len(inventory["included"])
            inventory["included_bytes"] = total
            inventory["finished_utc"] = now()
            raw_inventory = (json.dumps(inventory, indent=2) + "\n").encode()
            tar_bytes(archive, "_audit/collection.json", raw_inventory, 0)
            checksums = "".join(f"{entry['sha256']}  {entry['path']}\n" for entry in inventory["included"])
            tar_bytes(archive, "_audit/SHA256SUMS", checksums.encode(), 0)
            tar_bytes(archive, "_audit/collect-benchmark-evidence.py", Path(__file__).read_bytes(), 0)
        os.chmod(temp_name, 0o600)
        temp_name.replace(output)
        temp_name = None
        archive_hash = hashlib.sha256(output.read_bytes()).hexdigest()
        checksum_path.write_text(f"{archive_hash}  {output.name}\n")
        inventory_path.write_bytes(raw_inventory)
        print(json.dumps({"archive": str(output), "archive_bytes": output.stat().st_size,
                          "archive_sha256": archive_hash, "included_files": len(inventory["included"]),
                          "included_bytes": total, "omissions": len(inventory["omitted"]),
                          "inventory": str(inventory_path), "readiness": state}, indent=2))
    finally:
        if temp_name is not None:
            temp_name.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/home/ubuntu/wispr-on-chip"))
    parser.add_argument("--output", type=Path, required=True, help="fresh .tar.gz filename")
    parser.add_argument("--max-file-mib", type=int, default=8)
    parser.add_argument("--max-total-mib", type=int, default=128)
    parser.add_argument("--expected-pairs", type=int, default=51)
    args = parser.parse_args()
    if min(args.max_file_mib, args.max_total_mib, args.expected_pairs) <= 0:
        parser.error("limits and expected-pairs must be positive")
    collect(args.repo.resolve(), args.output.resolve(), args.max_file_mib * 1024**2,
            args.max_total_mib * 1024**2, args.expected_pairs)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f"Evidence collection failed: {error}", file=sys.stderr)
        sys.exit(1)
